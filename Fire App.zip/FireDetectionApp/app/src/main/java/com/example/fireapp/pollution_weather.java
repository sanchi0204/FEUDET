package com.example.fireapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class pollution_weather extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pollution_weather);
    }
}
